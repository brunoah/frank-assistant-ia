.\.venv\Scripts\Activate.ps1
