.\.venv\Scripts\Activate.ps1
python -m scripts.run