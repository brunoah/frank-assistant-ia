# 🤝 Contributing to FRANK

Merci de contribuer !

## Règles

1.  Fork le repo
2.  Crée une branche feature
3.  Commit clair et descriptif
4.  Pull Request documentée

## Code Style

-   Code clair et modulaire
-   Pas de clés API hardcodées
-   Respect de l'architecture existante

## Bug Report

Inclure : - OS - Version Python - Logs complets

------------------------------------------------------------------------

FRANK vise une architecture propre, scalable et professionnelle.
